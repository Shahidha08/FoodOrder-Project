export default function Footer() {
  return (
    <>
    <footer className="text-center">
        Food Delivery Website-2024-2025.All Rights Reserved by WSA
    </footer>
    </>
  )
}
